from original.ui import Command


def main():
    Command().run()


if __name__ == '__main__':
    main()
