package model.expression;

public enum ExpressionErrorType {
    LEFT_OPERAND_WRONG_TYPE,
    RIGHT_OPERAND_WRONG_TYPE,
    DIVISION_BY_ZERO,
    UNKNOWN
}
