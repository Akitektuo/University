package model.type;

public enum Types {
    NUMBER,
    BOOLEAN,
    STRING,
    REFERENCE,
    NUMBER_TO_BOOLEAN
}
