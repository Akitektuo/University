package container;

import java.util.concurrent.atomic.AtomicInteger;

public class IdDictionary<V> extends Dictionary<Integer, V> {
    private final AtomicInteger emptyAddress = new AtomicInteger();

    public int set(V value) {
        set(emptyAddress.incrementAndGet(), value);

        return emptyAddress.get();
    }
}
