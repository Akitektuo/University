#include "Configuration.h"

Configuration::Configuration(std::string key, std::string value)
{
	this->key = key;
	this->value = value;
}
