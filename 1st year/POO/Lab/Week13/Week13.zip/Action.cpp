#include "Action.h"

Action::Action(Repository* repository) : repository { repository } {}

Action::~Action() {}
