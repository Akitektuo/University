#pragma once
#include "Controller.h"

typedef struct
{
	Controller* controller;
} ConsoleUI;

void startConsoleUI();