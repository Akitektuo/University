#include "ConsoleUI.h"

int main()
{
    startConsoleUI();

    return 0;
}
