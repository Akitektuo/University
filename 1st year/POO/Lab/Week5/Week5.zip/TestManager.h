#pragma once

#include "RepositoryTest.h"
#include "ServiceTest.h"

void runAllTests();
