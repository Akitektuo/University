#pragma once

#include "Repository.h"
#include <cassert>

void runAllRepositoryTests();
