#include "TestManager.h"

void runAllTests()
{
	runAllRepositoryTests();
	runAllServiceTests();
}
