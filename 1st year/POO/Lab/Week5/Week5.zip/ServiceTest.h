#pragma once

#include "Service.h"
#include <cassert>

void runAllServiceTests();
