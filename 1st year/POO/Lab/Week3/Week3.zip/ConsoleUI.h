#pragma once
#include "ConsoleController.h"

typedef struct
{
	ConsoleController* controller;
} ConsoleUI;

void startConsoleUI();