#pragma once

#include <cassert>
#include "Service.h"

void testAll();