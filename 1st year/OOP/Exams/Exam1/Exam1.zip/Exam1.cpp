#include <iostream>
#include "ConsoleUI.h"

int main()
{
	ConsoleUI consoleUI;
	consoleUI.start();
	return 0;
}