#include "Car.h"

Car::Car(std::string name, std::string model, int year, std::string color) : name{ name }, model{ model }, year{ year }, color{ color } {}
