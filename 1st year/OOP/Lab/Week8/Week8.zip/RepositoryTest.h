#pragma once

#include "FileRepository.h"
#include <cassert>

constexpr auto REPOSITORY_TEST_FILE_NAME = "TestManager_RepositoryTest.txt";

void runAllRepositoryTests();
