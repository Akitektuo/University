#pragma once

#include "MemoryRepository.h"
#include <cassert>

void runAllRepositoryTests();
