#pragma once

#include "ArrayList.h"
#include "TrenchCoat.h"

class BaseRepository
{
	virtual bool add(const TrenchCoat& trenchCoat) = 0;
	virtual bool update(const TrenchCoat& trenchCoat) = 0;
	virtual bool remove(std::string trenchCoatName) = 0;

	virtual const ArrayList<TrenchCoat>& getTrenchCoatsAsArrayList() const = 0;
};

