def generate_chars(which, how_many):
    chars = ""
    for _ in range(how_many):
        chars += which
    return chars
