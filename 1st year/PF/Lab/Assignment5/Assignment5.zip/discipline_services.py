from domains import Student
from domains import Discipline
from domains import Grade
from exceptions import NoDataError
from repository import Repository
from randomiser import Randomiser
from validator import *
import generator

class DisciplineServices:

    def __init__(self):
        self.repository = Repository()

    def add(self, params):
        """
        Add a student or discipline to the repository

        Input: list - list of params (type, id, name)
        Output: -
        """
        validate_param_length(params, 3)

        atype = params[0]
        aid = params[1]
        name = params[2]

        validate_type(atype)
        if atype == STUDENT:
            validate_new_student_id(self.repository, aid)
        if atype == DISCIPLINE:
            validate_new_discipline_id(self.repository, aid)
        validate_name(name)

        aid = int(aid)
        if atype == STUDENT:
            self.repository.add_student(aid, name)
        if atype == DISCIPLINE:
            self.repository.add_discipline(aid, name)

    def remove(self, params):
        """
        Remove a student or discipline from the repository

        Input: list - list of params (type, id)
        Output: -
        """
        validate_param_length(params, 2)

        atype = params[0]
        aid = params[1]

        validate_type(atype)
        if atype == STUDENT:
            validate_existing_student_id(self.repository, aid)
        if atype == DISCIPLINE:
            validate_existing_discipline_id(self.repository, aid)

        aid = int(aid)
        if atype == STUDENT:
            self.repository.remove_student(aid)
        if atype == DISCIPLINE:
            self.repository.remove_discipline(aid)

    def update(self, params):
        """
        Update a student or discipline from the repository

        Input: list - list of params (type, id, new_name)
        Output: -
        """
        validate_param_length(params, 3)

        atype = params[0]
        aid = params[1]
        name = params[2]

        validate_type(atype)
        if atype == STUDENT:
            validate_existing_student_id(self.repository, aid)
        if atype == DISCIPLINE:
            validate_existing_discipline_id(self.repository, aid)
        validate_name(name)

        aid = int(aid)
        if atype == STUDENT:
            self.repository.update_student(aid, name)
        if atype == DISCIPLINE:
            self.repository.update_discipline(aid, name)

    def build_list(self, repository, header = "All students and diciplines"):
        """
        Parses a repository's data into a string to be printed

        Input: 
            Repository - repository to parse
            string - header to show at the beginning of the generated string
        Output: string - the parsed repository
        """
        if repository.is_empty():
            raise NoDataError("No data to show")

        data_string = "\n"
        data_string += header

        if repository.has_students() and repository.has_disciplines():
            data_string += "\n" + generator.generate_chars('-', 121) + "\n|" + generator.generate_chars(' ', 4) + "Students" + generator.generate_chars(' ', 47) + "|" + generator.generate_chars(' ', 4) + "Disciplines" +  generator.generate_chars(' ', 44) + "|\n" + generator.generate_chars('-', 121)
            
            students_length = len(repository.students)
            disciplines_length = len(repository.disciplines)
            max_length = max(students_length, disciplines_length)

            for i in range(max_length):
                if i < students_length:
                    student_string = str(repository.students[i])
                    data_string += "\n| " + student_string + generator.generate_chars(' ', 57 - len(student_string)) + " | "
                else:
                    data_string += "\n|" + generator.generate_chars(' ', 59) + "| "
                if i < disciplines_length:
                    discipline_string = str(repository.disciplines[i])
                    data_string += discipline_string + generator.generate_chars(' ', 57 - len(discipline_string)) + " |"
                else:
                    data_string += generator.generate_chars(' ', 58) + "|"

            data_string += "\n" + generator.generate_chars('-', 121)
            return data_string

        if repository.has_students():
            data_string += "\n" + generator.generate_chars('-', 60) + "\nStudents\n" + generator.generate_chars('-', 60)

            for student in repository.students:
                data_string += "\n" + str(student)

            return data_string

        if repository.has_disciplines():
            data_string += "\n" + generator.generate_chars('-', 60) + "\nDisciplines\n" + generator.generate_chars('-', 60)

            for discipline in repository.disciplines:
                data_string += "\n" + str(discipline)

            return data_string
