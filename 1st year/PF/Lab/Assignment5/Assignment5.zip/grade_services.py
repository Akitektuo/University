from domains import Student
from domains import Discipline
from domains import Grade
from exceptions import NoDataError
from repository import Repository
from randomiser import Randomiser
from validator import *
import generator

class GradeServices:

    def __init__(self):
        self.repository = Repository()

    def preload_list(self):
        """
        Adds to the repository a list of predefined values that are randomised

        Input: -
        Output: -
        """
        randomiser = Randomiser()
        repository_to_add = Repository()

        for i in range(10):
            random_name = randomiser.get_random_first_name() + " " + randomiser.get_random_last_name()

            repository_to_add.add_student(i, random_name)
            repository_to_add.add_discipline(i, randomiser.get_random_discipline_name())
        
        for i in range(10):
            repository_to_add.add_grade(
                randomiser.get_random(repository_to_add.disciplines),
                randomiser.get_random(repository_to_add.students),
                randomiser.get_random_grade()
            )

        self.repository.add_all(repository_to_add)

    def grade(self, params):
        """
        Gives a grade to a student at a given discipline

        Input: params - list of params (student_id, discipline_id, grade)
        Output: -
        """
        validate_param_length(params, 3)

        sid = params[0]
        did = params[1]
        grade = params[2]

        validate_existing_student_id(self.repository, sid)
        validate_existing_discipline_id(self.repository, did)
        validate_grade(grade)

        self.repository.add_grade(int(did), int(sid), float(grade))

    def search(self, params):
        """
        Searches by a keyword and returns a string with the results

        Input: params - list of params (keyword)
        Output: string - results of search
        """
        validate_param_length(params, 1)

        keyword = params[0]

        validate_keyword(keyword)

        repo_with_search = self.repository.search(keyword)
        return self.build_list(repo_with_search, "Results for the keyword '" + keyword + "'")

    def see_failing_students(self):
        """
        Returns a string representing the failing students

        Input: -
        Output: string - all failing students
        """
        faillings = self.repository.get_failing_students()

        if len(faillings) < 1:
            raise NoDataError("No students failing at one or more disciplines")

        students_to_show = "\nStudents failing:"
        count = 1
        for f in faillings:
            students_to_show += "\n" + str(count) + ". " + f.student_name + " at " + f.discipline_name + " with the average of " + f.get_formated_average()
            count += 1
        return students_to_show

    def see_best_students(self):
        """
        Returns a string representing all students ordered by their average grades

        Input: -
        Output: string - all students ordered by their average grades
        """
        best_students = self.repository.get_best_students()

        if len(best_students) < 1:
            raise NoDataError("No students with grades to show")

        best_students = sorted(best_students, key = lambda b: b.value, reverse = True)

        students_to_show = "\nBest students in descending order of average grades:"
        count = 1
        for b in best_students:
            students_to_show += "\n" + str(count) + ". " + b.student_name + " with the average of " + b.get_formated_average()
            count += 1
        return students_to_show

    def see_grades(self):
        """
        Returns a string representing all disciplines ordered by their average grades

        Input: -
        Output: string - all disciplines ordered by their average grades
        """
        disciplines_with_grades = self.repository.get_disciplines_with_grades()

        if len(disciplines_with_grades) < 1:
            raise NoDataError("No disciplines with grades to show")

        disciplines_with_grades = sorted(disciplines_with_grades, key = lambda d: d.value, reverse = True)

        disciplines_to_show = "\nDisciplines with grades in descending order of average grades:"
        count = 1
        for d in disciplines_with_grades:
            disciplines_to_show += "\n" + str(count) + ". " + d.discipline_name + " with the average of " + d.get_formated_average()
            count += 1
        return disciplines_to_show
