class Repository:

    def __init__(self):
        self.storage = []

    def get_count(self):
        return len(self.storage)

    def has_elements(self):
        return self.get_count() > 0

    def is_empty(self):
        return not self.has_elements()

    def clear(self):
        self.storage.clear()

    def add_all(self, other):
        self.storage.extend(other.storage)

    def find(self, condition):
        for e in self.storage:
            if condition(e):
                return e

    def add(self, element):
        self.storage.append(element)

    def remove(self, condition):
        initial_storage = list(self.storage)
        for e in initial_storage:
            if condition(e):
                self.storage.remove(e)
        
    def update(self, condition, modify):
        for e in self.storage:
            if condition(e):
                modify(e)