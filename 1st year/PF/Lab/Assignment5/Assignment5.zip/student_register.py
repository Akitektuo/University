from program import Program

Program().start()