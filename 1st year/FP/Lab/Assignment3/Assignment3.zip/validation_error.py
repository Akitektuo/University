class ValidationError(Exception):
    """
    Raised when an invalid value was found
    """
    pass